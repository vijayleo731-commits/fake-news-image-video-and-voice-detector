async function checkNews() {
    const newsText = document.getElementById('newsInput').value;

    const formData = new FormData();
    formData.append('news', newsText);

    const response = await fetch('/detect_news', {
        method: 'POST',
        body: formData
    });

    const data = await response.json();

    document.getElementById('newsResult').innerHTML =
        `Result: ${data.label} (${data.confidence}%)`;
}

async function checkImage() {

    const file = document.getElementById('imageFile').files[0];

    const formData = new FormData();
    formData.append('image', file);

    const response = await fetch('/detect_image', {
        method: 'POST',
        body: formData
    });

    const data = await response.json();

    document.getElementById('imageResult').innerHTML =
        `${data.result} | Size: ${data.size}`;
}

async function checkVideo() {

    const file = document.getElementById('videoFile').files[0];

    const formData = new FormData();
    formData.append('video', file);

    const response = await fetch('/detect_video', {
        method: 'POST',
        body: formData
    });

    const data = await response.json();

    document.getElementById('videoResult').innerHTML =
        `${data.result} | Frames: ${data.frames}`;
}