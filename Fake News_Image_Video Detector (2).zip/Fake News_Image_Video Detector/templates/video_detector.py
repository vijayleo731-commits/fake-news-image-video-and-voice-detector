import cv2

video_path = "sample.mp4"

cap = cv2.VideoCapture(video_path)

frame_count = 0

while cap.isOpened():
    ret, frame = cap.read()

    if not ret:
        break

    frame_count += 1

    cv2.imshow("Frame", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

print("Frames processed:", frame_count)

cap.release()
cv2.destroyAllWindows()