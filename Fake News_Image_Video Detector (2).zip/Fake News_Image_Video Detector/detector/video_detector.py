import cv2
import os

video_path = "sample.mp4"

# Check if file exists
if not os.path.exists(video_path):
    print("Error: Video file not found!")
    exit()

cap = cv2.VideoCapture(video_path)

# Check if video opened
if not cap.isOpened():
    print("Error: Could not open video.")
    exit()

frame_count = 0

while True:

    ret, frame = cap.read()

    if not ret:
        break

    frame_count += 1

    cv2.imshow("Frame", frame)

    # Press q to quit
    if cv2.waitKey(25) & 0xFF == ord('q'):
        break

print("Frames processed:", frame_count)

cap.release()
cv2.destroyAllWindows()