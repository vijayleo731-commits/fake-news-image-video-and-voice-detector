import streamlit as st
import librosa
import numpy as np
import tempfile
import os

st.set_page_config(
    page_title="AI Voice Detector",
    layout="centered"
)

st.title("🎤 Fake or Real Voice Detector")

st.write(
    "Upload a voice recording to check if it is likely real or AI-generated."
)

uploaded_audio = st.file_uploader(
    "Upload Audio File",
    type=["wav", "mp3"]
)

if uploaded_audio is not None:

    st.audio(uploaded_audio)

    # Keep original file extension
    file_extension = os.path.splitext(
        uploaded_audio.name
    )[1]

    temp_file = tempfile.NamedTemporaryFile(
        delete=False,
        suffix=file_extension
    )

    temp_file.write(uploaded_audio.read())
    temp_file.close()

    audio_path = temp_file.name

    try:
        # Load audio
        y, sr = librosa.load(
            audio_path,
            sr=16000,
            mono=True
        )

        duration = librosa.get_duration(
            y=y,
            sr=sr
        )

        st.write(
            "Duration:",
            round(duration, 2),
            "seconds"
        )

        # Extract MFCC features
        mfcc = librosa.feature.mfcc(
            y=y,
            sr=sr,
            n_mfcc=40
        )

        score = np.mean(np.abs(mfcc))

        st.write(
            "Analysis Score:",
            round(score, 2)
        )

        if score > 50:
            st.success(
                "✅ Voice appears REAL"
            )
        else:
            st.error(
                "❌ Voice may be AI Generated"
            )

    except Exception as e:
        st.error(f"Error: {str(e)}")

    finally:
        if os.path.exists(audio_path):
            os.remove(audio_path)